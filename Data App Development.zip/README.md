# RepeatDAD
Repeat Project for DAD

Project Includes Data Scrapped from 5 seasons of 5 different popular shows. 

The Data is Combined and Analysed by using MapReduce and RStudio
